# CGDL-for-Open-Set-Recognition
Code for Table3 in CVPR2020 paper: Conditional Gaussian Distribution Learning for Open Set Recognition: https://arxiv.org/abs/2003.08823

pytorch 1.4, python 3.6, ubuntu 16.04

For training, run lvae_train.py file;
For testing, run qmv.py file.
